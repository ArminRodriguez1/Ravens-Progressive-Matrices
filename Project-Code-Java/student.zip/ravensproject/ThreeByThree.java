package ravensproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * This class solves for the RPM that have only one object
 * in a figure. This class only deals with 2 by 2 RPMs.
 */


public class ThreeByThree {

	private RavensProblem problem;

	//hash map for Ravens Figure
	@SuppressWarnings("unused")
	private HashMap<String, RavensFigure> RF;
	//Ravens figure
	private RavensFigure RFE, RFF, RFH, RF1, RF2, RF3, RF4, RF5, RF6, RF7, RF8;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<Map> ravensObjects = new ArrayList(); //array to list the objects from a Ravens object

	private List<RavensObject> objectsE = new ArrayList();
	private List<RavensObject> objectsF = new ArrayList();
	private List<RavensObject> objectsH = new ArrayList();
	private List<RavensObject> objects1 = new ArrayList();
	private List<RavensObject> objects2 = new ArrayList();
	private List<RavensObject> objects3 = new ArrayList();
	private List<RavensObject> objects4 = new ArrayList();
	private List<RavensObject> objects5 = new ArrayList();
	private List<RavensObject> objects6 = new ArrayList();
	private List<RavensObject> objects7 = new ArrayList();
	private List<RavensObject> objects8 = new ArrayList();
	
	//Hash map of Ravens object
	@SuppressWarnings("unused")
	private HashMap<String, RavensObject> ROE, ROF, ROH, RO1, RO2, RO3, RO4, RO5, RO6, RO7, RO8;
	//Ravens object in each figure
	@SuppressWarnings("unused")
	private RavensObject ROf, ROg, ROh, ROi, ROm, ROn, ROo;
	//attributes for Ravens object
	@SuppressWarnings("unused")
	private HashMap<String, String> ROfa, ROga, ROha, ROia, ROma, ROna, ROoa;
	
	@SuppressWarnings("unused")
	private String shapeC, fillC, shapeB, fillB; //for the object c
	@SuppressWarnings("unused")
	private String shapeAns, fillAns, shapeAlignmentAns; //potential result

	@SuppressWarnings("unused")
	private String angleA, angleB, angleC, angleAns, shapeAlignmentA, shapeAlignmentC, shapeAlignmentB; //angle of C for rotation cases
	
	private int sizeE, sizeF, sizeH; //number of objects in figure E, F and H

	public ThreeByThree (RavensProblem problem) {
		this.problem = problem;
	}

	public int ThreeByThreeRPM() {
		RFigures(problem);
		//System.out.println("Size of RFE/no of objects: " + RFE.getObjects().size());
		int tempAns = -1;
		RObjects();
		NumberOfObjects();

		try {
			if (sizeE == 2 && sizeF == 2) { //when the total number of objects are equal
				tempAns = equalObjectsSize();
			} else if (sizeE != sizeF) {//when the total number of objects are not equal
				tempAns = increaseObject();
			}
		} catch(NullPointerException e){
			System.out.println("Exception thrown  :" + e);
		}
		return tempAns;
	}
	
	private int increaseObject(){ //when objects are increased, doesn't account for size or fill
		int ans = -1;
		NumberOfObjects();
		int increment = sizeF - sizeE;
		int anssize = 0; //potential answer size
		if (increment == 1) {
			anssize = sizeH + increment;
		} else if (increment == 2) {
			anssize = sizeH + increment +1;
		}
		try {
			for (int i = 0; i < ravensObjects.size(); i++) {
				if (ravensObjects.get(i).size() == anssize){
					ans = i+1;
					return ans;
				}
			}
		} catch(NullPointerException e){
			System.out.println("Exception thrown  :" + e);
		}
		return ans;
	}
	
	private int equalObjectsSize() { //equal number of objects from left to right but account for the change in the size
		int ans = -1;
		NumberOfObjects();
		objectMethod();

		try {
			if (equalEF()){
				//System.out.println("enter the statement");
				if (sizeH == 3) {
					if ((objectsH.get(0).getAttributes().get("size").equals(objects1.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects1.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects1.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects1.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects1.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects1.get(2).getAttributes().get("shape"))))) {
						ans = 1;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects2.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects2.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects2.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects2.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects2.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects2.get(2).getAttributes().get("shape"))))) {
						ans = 2;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects3.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects3.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects3.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects3.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects3.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects3.get(2).getAttributes().get("shape"))))) {
						ans = 3;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects4.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects4.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects4.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects4.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects4.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects4.get(2).getAttributes().get("shape"))))) {
						ans = 4;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects5.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects5.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects5.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects5.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects5.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects5.get(2).getAttributes().get("shape"))))) {
						ans = 5;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects6.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects6.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects6.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects6.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects6.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects6.get(2).getAttributes().get("shape"))))) {
						ans = 6;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects7.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects7.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects7.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects7.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects7.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects7.get(2).getAttributes().get("shape"))))) {
						ans = 7;
					} else if ((objectsH.get(0).getAttributes().get("size").equals(objects8.get(0).getAttributes().get("size"))) && 
							(objectsH.get(0).getAttributes().get("shape").equals(objects8.get(0).getAttributes().get("shape"))) &&
							((objectsH.get(1).getAttributes().get("size").equals(objects8.get(1).getAttributes().get("size"))) && 
									(objectsH.get(1).getAttributes().get("shape").equals(objects8.get(1).getAttributes().get("shape")))) && 
							((objectsH.get(2).getAttributes().get("size").equals(objects8.get(2).getAttributes().get("size"))) && 
									(objectsH.get(2).getAttributes().get("shape").equals(objects8.get(2).getAttributes().get("shape"))))) {
						ans = 8;
					}
				}
				return ans;
			}
		} catch(NullPointerException e){
			System.out.println("Exception thrown  :" + e);
		}
		return ans;
	}
	
	//to check if E and F are same like in problem C-01
	
	private boolean equalEF(){ //C-01
		NumberOfObjects();
		if (sizeE == 2 && sizeF == 2) {
			if ((objectsE.get(0).getAttributes().get("size").equals(objectsF.get(0).getAttributes().get("size"))) && 
					(objectsE.get(0).getAttributes().get("shape").equals(objectsF.get(0).getAttributes().get("shape"))) &&
					((objectsE.get(1).getAttributes().get("size").equals(objectsF.get(1).getAttributes().get("size"))) && 
							(objectsE.get(1).getAttributes().get("shape").equals(objectsF.get(1).getAttributes().get("shape"))))) {
				return true;
			}
		}
		return false;
	}
		
	//create objects for equal method
	private void objectMethod() {
		NumberOfObjects();
		RavensObject thisObjectE = null;
		RavensObject thisObjectF = null;
		RavensObject thisObjectH = null;
		RavensObject thisObject1 = null;
		RavensObject thisObject2 = null;
		RavensObject thisObject3 = null;
		RavensObject thisObject4 = null;
		RavensObject thisObject5 = null;
		RavensObject thisObject6 = null;
		RavensObject thisObject7 = null;
		RavensObject thisObject8 = null;
	
		try {
			for (String objectNameE : RFE.getObjects().keySet()) { //objectName1 is for E
				thisObjectE = RFE.getObjects().get(objectNameE);
				objectsE.add(thisObjectE);
//				System.out.println("size of E " + thisObjectE.getAttributes().get("size"));
//				System.out.println("shape of E " + thisObjectE.getAttributes().get("shape"));
			}
	
			for (String objectNameF : RFF.getObjects().keySet()) { //objectName2 is for F
				thisObjectF = RFF.getObjects().get(objectNameF);
				objectsF.add(thisObjectF);
//				System.out.println("size of F " + thisObjectF.getAttributes().get("size"));
//				System.out.println("shape of F " + thisObjectF.getAttributes().get("shape"));
			}
	
			for (String objectNameH : RFH.getObjects().keySet()) {//for objectName3 is for H
				thisObjectH = RFH.getObjects().get(objectNameH);
				objectsH.add(thisObjectH);
//				System.out.println("size of H " + thisObjectH.getAttributes().get("size"));
//				System.out.println("size H " + objectsH.get(0).getAttributes().get("shape"));
			}
			
			for (String objectName1 : RF1.getObjects().keySet()) {
				thisObject1 = RF1.getObjects().get(objectName1);
				objects1.add(thisObject1);
			}
			
			for (String objectName2 : RF2.getObjects().keySet()) {
				thisObject2 = RF2.getObjects().get(objectName2);
				objects2.add(thisObject2);
			}
			
			for (String objectName3 : RF3.getObjects().keySet()) {
				thisObject3 = RF3.getObjects().get(objectName3);
				objects3.add(thisObject3);
			}
			
			for (String objectName4 : RF4.getObjects().keySet()) {
				thisObject4 = RF4.getObjects().get(objectName4);
				objects4.add(thisObject4);
			}
			
			for (String objectName5 : RF5.getObjects().keySet()) {
				thisObject5 = RF5.getObjects().get(objectName5);
				objects5.add(thisObject5);
			}
			
			for (String objectName6 : RF6.getObjects().keySet()) {
				thisObject6 = RF6.getObjects().get(objectName6);
				objects6.add(thisObject6);
			}
			
			for (String objectName7 : RF7.getObjects().keySet()) {
				thisObject7 = RF7.getObjects().get(objectName7);
				objects7.add(thisObject7);
			}
			
			for (String objectName8 : RF8.getObjects().keySet()) {
				thisObject8 = RF8.getObjects().get(objectName8);
				objects8.add(thisObject8);
			}
			
		} catch(NullPointerException e){
			System.out.println("Exception thrown  :" + e);
		}
	}
	
	//total number of objects in E, F and H
	private void NumberOfObjects(){
		sizeE = RFE.getObjects().size();
		sizeF = RFF.getObjects().size();
		sizeH = RFH.getObjects().size();
	}

	//create ravens figure for question figure and answer choices
	private void RFigures(RavensProblem problem) { //returns the object attributes in a list

		//these are the Ravens Figure from the problem
		RFE = problem.getFigures().get("E");
		RFF = problem.getFigures().get("F");
		RFH = problem.getFigures().get("H");

		//these are the Ravens Figure from the solution
		RF1 = problem.getFigures().get("1");
		RF2 = problem.getFigures().get("2");
		RF3 = problem.getFigures().get("3");
		RF4 = problem.getFigures().get("4");
		RF5 = problem.getFigures().get("5");
		RF6 = problem.getFigures().get("6");
		RF7 = problem.getFigures().get("7");
		RF8 = problem.getFigures().get("8");		
	}

	//create ravens objects for each figure
	private void RObjects() {

		//get the Ravens Objects from the problem figures
		ROE = RFE.getObjects();
		ROF = RFF.getObjects();
		ROH = RFH.getObjects();

		//get the Ravens Objects from the problem solutions
		RO1 = RF1.getObjects();
		RO2 = RF2.getObjects();
		RO3 = RF3.getObjects();
		RO4 = RF4.getObjects();
		RO5 = RF5.getObjects();
		RO6 = RF6.getObjects();
		RO7 = RF7.getObjects();
		RO8 = RF8.getObjects();
		
		//add answer ravens objects to a list
		ravensObjects.add(RO1);
		ravensObjects.add(RO2);
		ravensObjects.add(RO3);
		ravensObjects.add(RO4);
		ravensObjects.add(RO5);
		ravensObjects.add(RO6);
		ravensObjects.add(RO7);
		ravensObjects.add(RO8);
	}
}
