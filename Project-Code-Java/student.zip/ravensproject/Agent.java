package ravensproject;

import java.util.HashMap;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

// Uncomment these lines to access image processing.
//import java.awt.Image;
//import java.io.File;
//import javax.imageio.ImageIO;

/**
 * Your Agent for solving Raven's Progressive Matrices. You MUST modify this
 * file.
 * 
 * You may also create and submit new files in addition to modifying this file.
 * 
 * Make sure your file retains methods with the signatures:
 * public Agent()
 * public char Solve(RavensProblem problem)
 * 
 * These methods will be necessary for the project's main method to run.
 * 
 */
public class Agent {
	/**
	 * The default constructor for your Agent. Make sure to execute any
	 * processing necessary before your Agent starts solving problems here.
	 * 
	 * Do not add any variables to this signature; they will not be used by
	 * main().
	 * 
	 */
	public Agent() {

	}
	/**
	 * The primary method for solving incoming Raven's Progressive Matrices.
	 * For each problem, your Agent's Solve() method will be called. At the
	 * conclusion of Solve(), your Agent should return an int representing its
	 * answer to the question: 1, 2, 3, 4, 5, or 6. Strings of these ints 
	 * are also the Names of the individual RavensFigures, obtained through
	 * RavensFigure.getName(). Return a negative number to skip a problem.
	 * 
	 * Make sure to return your answer *as an integer* at the end of Solve().
	 * Returning your answer as a string may cause your program to crash.
	 * @param problem the RavensProblem your agent should solve
	 * @return your Agent's answer to this problem
	 */
	public int Solve(RavensProblem problem) {
		System.out.println("************");
		System.out.println("Problem name: " + problem.getName());
		int ans = -1;

		//check if the problem has verbal or not
		if (problem.hasVerbal()) {
			HashMap<String, RavensFigure> RF = problem.getFigures();
			System.out.println("");
			System.out.println("Size of RF: "+ RF.size());
			/*
			 * 2 by 2 RPM problem have 9 Ravens Figure and 3 by 3 RPM have 16 Ravens Figure.
			 * Find the total number of Ravens Figure and put check accordingly.
			 */

			if (RF.size() < 10) {
				//these are the Ravens Figure from the problem
				RavensFigure RFA = RF.get("A");
				//get the Ravens Figure from the problem figures
				HashMap<String, RavensObject> ROA = RFA.getObjects();

				int numberOfObjects = ROA.size();
				System.out.println("");
				System.out.println("The size of the hashmap is: " + numberOfObjects);

				if (numberOfObjects == 1) {
					TwoByTwoOneObject oneobject = new TwoByTwoOneObject(problem);
					ans = oneobject.test();
				} else {
					ans = -1;
				}
				System.out.println("");
				System.out.println("The answer is: " + ans);
				System.out.println("");
			}
		}
		return ans;
	}
}
